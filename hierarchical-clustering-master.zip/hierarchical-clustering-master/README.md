# Hierarchical-clustering
Own Hierarchical Clustering algorithm implementation without using Sklearn's in-built function. Dynamic programming approach is used to achieve it and numpy is used for matrices operations.

Hierarchical clustering's own code is written which returns which data points/cluster are connecting and target cluster.
Dynamic programming approach is used. Demo is available in Jupyter Notebook.

You can use the code directly also using the .py file.

Code is the best documentation! Necessary comments are added which will be sufficient to understand the code and start using it.
Please feel free to use the code and/or contribute to improve the codebase.
Also, checkout my other Machine library code implementation in my other Repos.

View my portfolio and contact me using - 
www.mithunjmistry.com
